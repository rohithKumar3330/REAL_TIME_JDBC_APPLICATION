package connection;

public class DeptNotFoundException extends Exception {
	
}
